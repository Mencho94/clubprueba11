package arg.org.centro8.curso.java.club.repositories;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import arg.org.centro8.curso.java.club.connectors.Connector;
import arg.org.centro8.curso.java.club.entities.Socio;

public class SocioRepository {
    private Connection conn = Connector.getConnection();
    
    public void save(Socio socio) {
        if (socio == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into socio (nombre, apellido, edad, idActividad) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, socio.getNombre());
            ps.setString(2, socio.getApellido());
            ps.setInt(3, socio.getEdad());
            ps.setInt(4, socio.getIdActividad());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                socio.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Socio> getAll() {
        List<Socio> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from socio")) {
            while (rs.next()) {
                list.add(new Socio(
                        rs.getInt("id"),            // id
                        rs.getString("nombre"),     // nombre
                        rs.getString("apellido"),   // apellido
                        rs.getInt("edad"),          // edad
                        rs.getInt("idActividad")        // idActividad
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Socio getById(int id) {
        return getAll()
                .stream()
                .filter(a -> a.getId() == id)
                .findFirst()
                .orElse(new Socio());
    }

    public List<Socio>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(a->a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                    .toList();      //JDK 16 o sup
    }
}





